export function log(message){
    console.log('Adicionando log',message);
}